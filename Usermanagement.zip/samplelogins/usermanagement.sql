-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2021 at 06:42 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `samplelogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_logs`
--

CREATE TABLE `app_logs` (
  `log_id` int(11) NOT NULL,
  `Timestamp` varchar(255) DEFAULT NULL,
  `Action` varchar(255) DEFAULT NULL,
  `TableName` varchar(255) DEFAULT NULL,
  `RecordID` varchar(255) DEFAULT NULL,
  `SqlQuery` varchar(255) DEFAULT NULL,
  `UserID` varchar(255) DEFAULT NULL,
  `ServerIP` varchar(255) DEFAULT NULL,
  `RequestUrl` text DEFAULT NULL,
  `RequestData` text DEFAULT NULL,
  `RequestCompleted` varchar(255) DEFAULT NULL,
  `RequestMsg` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `app_logs`
--

INSERT INTO `app_logs` (`log_id`, `Timestamp`, `Action`, `TableName`, `RecordID`, `SqlQuery`, `UserID`, `ServerIP`, `RequestUrl`, `RequestData`, `RequestCompleted`, `RequestMsg`) VALUES
(1, '2021-05-16 18:32:09', 'add', 'users', '1', 'INSERT INTO users (`username`, `email`, `password`, `created_by`, `user_role_id`)  VALUES (?, ?, ?, ?, ?)', NULL, '::1', 'index/register', '{\"username\":\"lotusp8696\",\"email\":\"lotusp8696@gmail.com\",\"password\":\"$2y$10$osU6M1xer.DvYBUEOC7DJO\\/v\\/bRJql0XNoSiNOo.mYdR5EaSLIuLe\",\"created_by\":\"Own\",\"user_role_id\":\"1\"}', 'true', NULL),
(2, '2021-05-16 18:32:10', 'userlogin', 'users', '1', 'SELECT   * FROM users WHERE  (is_deleted IS NULL OR is_deleted != ?) AND username = ?  OR email = ?  LIMIT 1', '1', '::1', 'index/register', '{\"username\":\"lotusp8696\",\"email\":\"lotusp8696@gmail.com\",\"password\":\"$2y$10$osU6M1xer.DvYBUEOC7DJO\\/v\\/bRJql0XNoSiNOo.mYdR5EaSLIuLe\",\"created_by\":\"Own\",\"user_role_id\":\"1\"}', 'true', NULL),
(3, '2021-05-16 18:32:15', 'list', 'roles', '2,1', 'SELECT SQL_CALC_FOUND_ROWS  role_id, role_name, date_created, date_updated FROM roles WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY roles.role_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'roles', '[]', 'true', NULL),
(4, '2021-05-16 18:32:18', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(5, '2021-05-16 18:32:18', 'list', 'roles', '2,1', 'SELECT SQL_CALC_FOUND_ROWS  role_id, role_name, date_created, date_updated FROM roles WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY roles.role_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'roles', '[]', 'true', NULL),
(6, '2021-05-16 18:32:20', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(7, '2021-05-16 18:32:26', 'list', 'role_permissions', '5,4,3,2,1', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 20', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(8, '2021-05-16 18:32:26', 'list', 'role_permissions', '5,4,3,2,1', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 20', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(9, '2021-05-16 18:32:27', 'list', 'role_permissions', '5,4,3,2,1', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 20', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(10, '2021-05-16 18:32:28', 'view', 'role_permissions', '25', 'SELECT   permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) AND role_permissions.permission_id = ?  LIMIT 1', '1', '::1', 'role_permissions/view/25', '[]', 'true', NULL),
(11, '2021-05-16 18:32:31', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(12, '2021-05-16 18:32:32', 'list', 'roles', '2,1', 'SELECT SQL_CALC_FOUND_ROWS  role_id, role_name, date_created, date_updated FROM roles WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY roles.role_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'roles', '[]', 'true', NULL),
(13, '2021-05-16 18:32:35', 'list', 'users', '1', 'SELECT SQL_CALC_FOUND_ROWS  id, username, email, created_at, created_by, user_role_id, date_created, date_updated FROM users WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY users.id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'users', '[]', 'true', NULL),
(14, '2021-05-16 18:32:37', 'list', 'users', '1', 'SELECT SQL_CALC_FOUND_ROWS  id, username, email, created_at, created_by, user_role_id, date_created, date_updated FROM users WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY users.id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'users', '[]', 'true', NULL),
(15, '2021-05-16 18:32:38', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(16, '2021-05-16 18:32:38', 'list', 'roles', '2,1', 'SELECT SQL_CALC_FOUND_ROWS  role_id, role_name, date_created, date_updated FROM roles WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY roles.role_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'roles', '[]', 'true', NULL),
(17, '2021-05-16 18:32:39', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(18, '2021-05-16 18:32:40', 'list', 'users', '1', 'SELECT SQL_CALC_FOUND_ROWS  id, username, email, created_at, created_by, user_role_id, date_created, date_updated FROM users WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY users.id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'users', '[]', 'true', NULL),
(19, '2021-05-16 18:32:41', 'list', 'users', '1', 'SELECT SQL_CALC_FOUND_ROWS  id, username, email, created_at, created_by, user_role_id, date_created, date_updated FROM users WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY users.id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'users', '[]', 'true', NULL),
(20, '2021-05-16 18:32:42', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(21, '2021-05-16 18:34:41', 'list', 'role_permissions', '25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6', 'SELECT SQL_CALC_FOUND_ROWS  permission_id, role_id, page_name, action_name, date_created, date_updated FROM role_permissions WHERE  (is_deleted IS NULL OR is_deleted != ?) ORDER BY role_permissions.permission_id DESC  LIMIT 20 OFFSET 0', '1', '::1', 'role_permissions', '[]', 'true', NULL),
(22, '2021-05-16 18:34:53', 'userlogout', 'users', NULL, NULL, '1', '::1', 'index/logout', '[]', 'true', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(255) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `date_deleted` datetime DEFAULT NULL,
  `is_deleted` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `date_created`, `date_updated`, `date_deleted`, `is_deleted`) VALUES
(1, 'Administrator', NULL, NULL, NULL, NULL),
(2, 'User', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `page_name` varchar(255) NOT NULL,
  `action_name` varchar(255) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `date_deleted` datetime DEFAULT NULL,
  `is_deleted` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`permission_id`, `role_id`, `page_name`, `action_name`, `date_created`, `date_updated`, `date_deleted`, `is_deleted`) VALUES
(1, 1, 'users', 'list', NULL, NULL, NULL, NULL),
(2, 1, 'users', 'view', NULL, NULL, NULL, NULL),
(3, 1, 'users', 'add', NULL, NULL, NULL, NULL),
(4, 1, 'users', 'edit', NULL, NULL, NULL, NULL),
(5, 1, 'users', 'editfield', NULL, NULL, NULL, NULL),
(6, 1, 'users', 'delete', NULL, NULL, NULL, NULL),
(7, 1, 'users', 'import_data', NULL, NULL, NULL, NULL),
(8, 1, 'users', 'userregister', NULL, NULL, NULL, NULL),
(9, 1, 'users', 'accountedit', NULL, NULL, NULL, NULL),
(10, 1, 'users', 'accountview', NULL, NULL, NULL, NULL),
(11, 1, 'role_permissions', 'list', NULL, NULL, NULL, NULL),
(12, 1, 'role_permissions', 'view', NULL, NULL, NULL, NULL),
(13, 1, 'role_permissions', 'add', NULL, NULL, NULL, NULL),
(14, 1, 'role_permissions', 'edit', NULL, NULL, NULL, NULL),
(15, 1, 'role_permissions', 'editfield', NULL, NULL, NULL, NULL),
(16, 1, 'role_permissions', 'delete', NULL, NULL, NULL, NULL),
(17, 1, 'roles', 'list', NULL, NULL, NULL, NULL),
(18, 1, 'roles', 'view', NULL, NULL, NULL, NULL),
(19, 1, 'roles', 'add', NULL, NULL, NULL, NULL),
(20, 1, 'roles', 'edit', NULL, NULL, NULL, NULL),
(21, 1, 'roles', 'editfield', NULL, NULL, NULL, NULL),
(22, 1, 'roles', 'delete', NULL, NULL, NULL, NULL),
(23, 2, 'users', 'userregister', NULL, NULL, NULL, NULL),
(24, 2, 'users', 'accountedit', NULL, NULL, NULL, NULL),
(25, 2, 'users', 'accountview', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(255) NOT NULL,
  `login_session_key` varchar(255) DEFAULT NULL,
  `email_status` varchar(255) DEFAULT NULL,
  `password_expire_date` datetime DEFAULT '2021-08-16 00:00:00',
  `password_reset_key` varchar(255) DEFAULT NULL,
  `user_role_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `date_deleted` datetime DEFAULT NULL,
  `is_deleted` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `created_by`, `login_session_key`, `email_status`, `password_expire_date`, `password_reset_key`, `user_role_id`, `date_created`, `date_updated`, `date_deleted`, `is_deleted`) VALUES
(1, 'lotusp8696', 'lotusp8696@gmail.com', '$2y$10$osU6M1xer.DvYBUEOC7DJO/v/bRJql0XNoSiNOo.mYdR5EaSLIuLe', '2021-05-16 16:32:09', 'Own', NULL, NULL, '2021-08-16 00:00:00', NULL, 1, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_logs`
--
ALTER TABLE `app_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_logs`
--
ALTER TABLE `app_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
