<div class="container">
	<div style="margin:40px 0;">
		<div class="animated bounce">
			<h4 class="bold text-success"><i class="material-icons animated fadeIn infinite">thumb_up</i> Thank You For Contacting Us ...</h4>
			<hr />
			<p class="text-muted">We Will Get Back to You Soon.</p>
		</div>
	</div>
	<?php
	if (DEVELOPMENT_MODE) {
	?>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/contact_sent.php</i></small>
	<?php
	}
	?>

</div>